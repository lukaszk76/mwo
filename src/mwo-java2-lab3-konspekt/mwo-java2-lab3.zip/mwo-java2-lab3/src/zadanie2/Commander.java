package zadanie2;

public class Commander {
	
	public static void main(String args[]) {
		//TODO to be implemented
	}
		
}
