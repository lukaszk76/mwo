package pl.edu.agh.mwo.java.crawler;

import java.util.List;

public interface SentenceFinder {
	public List<String> findSentences(List<String> sentences);
}